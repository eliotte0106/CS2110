/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 ball ball.png 
 * Time-stamp: Friday 07/15/2022, 21:52:22
 * 
 * Image Information
 * -----------------
 * ball.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BALL_H
#define BALL_H

extern const unsigned short ball[1850];
#define BALL_SIZE 3700
#define BALL_LENGTH 1850
#define BALL_WIDTH 50
#define BALL_HEIGHT 37

#endif

