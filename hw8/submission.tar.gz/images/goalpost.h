/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 goalpost goalpost.png 
 * Time-stamp: Friday 07/15/2022, 22:17:10
 * 
 * Image Information
 * -----------------
 * goalpost.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GOALPOST_H
#define GOALPOST_H

extern const unsigned short goalpost[1850];
#define GOALPOST_SIZE 3700
#define GOALPOST_LENGTH 1850
#define GOALPOST_WIDTH 50
#define GOALPOST_HEIGHT 37

#endif

