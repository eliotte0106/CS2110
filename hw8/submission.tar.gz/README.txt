This game is a soccer game.
Use the delete button (backspace) to return to the start screen.
Use the return button (enter) to go to the next screen.
Use Up/Down/Left/Right keys to move around.
Put the soccer ball into the goalpost.
You will get the score by the time spent you put the soccer ball in the goalpost.